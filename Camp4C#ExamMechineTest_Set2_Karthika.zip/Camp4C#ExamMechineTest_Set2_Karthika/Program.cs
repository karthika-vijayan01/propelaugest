﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    internal class Program
    {
            static void Main(string[] args)
            {
            Dictionary<string, Employee> employees = new Dictionary<string, Employee>();

            
            employees.Add("EMP01", new Employee("Karthika", 1000.10m));
            employees.Add("EMP02", new Employee("Pradeep", 2000.00m));
            employees.Add("EMP03", new Employee("Advika", 8000.0m));
            employees.Add("EMP04", new Employee("Advin", 10000.10m));

            try
            {
                Console.WriteLine("Enter employee ID:");
                string employeeId = Console.ReadLine();
                Console.WriteLine("Enter employee Name:");
                string employeeName = Console.ReadLine();

                
                if (!employees.ContainsKey(employeeId))
                {
                    throw new KeyNotFoundException("Employee ID not found.");
                }

              
                Employee selectedEmployee = employees[employeeId];
                if (selectedEmployee.GetName() != employeeName)
                {
                    throw new ArgumentException("Employee name does not match the ID.");
                }

                Console.WriteLine("Employee verified successfully!");

                Console.WriteLine($"Welcome Employee {selectedEmployee.GetType().Name}. Choose an option: ");
                    Console.WriteLine("1. Deposit\n2. Withdraw\n3. Check Balance");
                    int choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter deposit amount:");
                            decimal depositAmount = decimal.Parse(Console.ReadLine());
                            selectedEmployee.Deposit(depositAmount);
                            break;

                        case 2:
                            Console.WriteLine("Enter withdraw amount:");
                            decimal withdrawAmount = decimal.Parse(Console.ReadLine());
                            selectedEmployee.Withdraw(withdrawAmount);
                            break;

                        case 3:
                            Console.WriteLine($"Your current balance is: {selectedEmployee.CheckBalance()}");
                            break;

                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                }
                catch (FormatException e)
                {
                    Console.WriteLine($"Invalid input: {e.Message}");
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine($"Error: {e.Message}");
                }
                catch (InvalidOperationException e)
                {
                    Console.WriteLine($"Error: {e.Message}");
                }
                catch (KeyNotFoundException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (Exception e)
                {
                    Console.WriteLine($"An unexpected error occurred: {e.Message}");
                }
            Console.ReadKey();
            }
    }

}
  
