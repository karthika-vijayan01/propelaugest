﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    public class Employee : IPayable
    {
        private decimal balance;
        private string employeeName;

        public Employee(string name, decimal initialBalance)
        {
            employeeName = name;
            balance = initialBalance;
        }
        //NAME
        public string GetName()
        {
            return employeeName;
        }
        // DEPOSIT METHOD
        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Amount to deposit should be positive");
            }
            balance += amount;
            Console.WriteLine($"{amount} deposited successfully. Current balance: {balance}");
        }

        //WITHDRAW METHOD
        
        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Amount to withdraw should be positive");
            }
            if (amount > balance)
            {
                throw new InvalidOperationException("Insufficient funds.");
            }
            balance -= amount;
            Console.WriteLine($"{amount} withdrawn successfully. Current balance: {balance}");
        }
        //BALANCE METHOD
        public decimal CheckBalance()
        {
            return balance;
        }

        void IPayable.CheckBalance()
        {
            throw new NotImplementedException();
        }
    }
}

    
