﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    // SINGLE INTERFACE

    /* internal interface Interface1
     {
         //Single interface
         void method1();
         void method2();
     }*/

    //MULTIPLE INTERFACES
    internal interface IPayable
    {
        
        void Deposit(decimal amount);
        void Withdraw(decimal amount);
        void CheckBalance();
    }

}

    



